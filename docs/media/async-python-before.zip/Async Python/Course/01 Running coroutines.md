# Running coroutines

Calling an async function creates a coroutine. Awaiting it gives the event loop a chance to run other work.

## Two jobs, one event loop

An async job can start, yield once, and finish. If you await each job inside a loop, the next job starts only after the previous one finishes.

```python
for label in labels:
    await job(label)
```

**Try to predict it.** For jobs A and B, can B start before A finishes? Read [[Sources/Event loop notes|the course notes]] and compare the two schedules.

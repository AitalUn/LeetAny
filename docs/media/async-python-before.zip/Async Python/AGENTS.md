# Course instructions

Write in English. Keep source notes in Sources/ unchanged. Maintain short explanations in Wiki/ and link each one back to its source.
